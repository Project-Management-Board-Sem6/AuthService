//package nl.fontys.sem6.auth.security.services;
//
////import nl.fontys.sem6.mang.model.User;
////import nl.fontys.sem6.mang.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//
//import javax.transaction.Transactional;
//
//@Service
//public class UserDetailsServiceImpl implements UserDetailsService {
//
//	@Autowired
//	UserRepository userRepository;
//
//	@Override
//	@Transactional
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//
//	User user = userRepository.findByUsername(username).orElseThrow(
//	        () -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
//
//	    return UserPrincipal.build(user);
//	}
//}
package nl.fontys.sem6.auth.security.services;

import nl.fontys.sem6.auth.config.UserDetailsRequest;
import nl.fontys.sem6.auth.config.UserDetailsResponse;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.MessageListenerContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;


@Service
public class UserDetailsServiceImpl implements UserDetailsService {

//	@Autowired
//	private RabbitTemplate rabbitTemplate;
//
//	@Override
//	@Transactional
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		UserDetailsRequest request = new UserDetailsRequest(username);
//		UserDetailsResponse response = (UserDetailsResponse) rabbitTemplate.convertSendAndReceive("userDetailsQueue", request);
//
//		if (response == null) {
//			throw new UsernameNotFoundException("User Not Found with -> username or email : " + username);
//		}
//
//		return UserPrincipal.build(response);
//	}
@Autowired
private RestTemplate restTemplate;

//	@Value("${main.service.url}")
	private String mainServiceUrl;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDetailsResponse response = restTemplate.getForObject("http://localhost:8081/api/user/" + username, UserDetailsResponse.class);

		if (response == null) {
			throw new UsernameNotFoundException("User Not Found with -> username : " + username);
		}

		return UserPrincipal.build(response);
	}
}
